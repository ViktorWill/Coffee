import { useState, useEffect, useMemo } from 'react'
import { useKV } from '@github/spark/hooks'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Toaster } from '@/components/ui/sonner'
import { CoffeeBean, Extraction, CoffeeType, TastingProfile } from '@/lib/types'
import { COFFEE_ORIGINS, ROAST_LEVELS } from '@/lib/constants'
import { BeanCard } from '@/components/BeanCard'
import { NewBeanDialog } from '@/components/NewBeanDialog'
import { EditBeanDialog } from '@/components/EditBeanDialog'
import { ExtractionDialog } from '@/components/ExtractionDialog'
import { TastingProfileDialog } from '@/components/TastingProfileDialog'
import { AuthDialog } from '@/components/AuthDialog'
import { UserHeader } from '@/components/UserHeader'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { Coffee, Funnel, Plus, SortAscending, Faders } from '@phosphor-icons/react'
import { ulid } from 'ulid'
import { toast } from 'sonner'

type SortOption = 'newest' | 'oldest' | 'name-asc' | 'name-desc' | 'origin-asc' | 'origin-desc' | 'roast-asc' | 'roast-desc'

function App() {
  const [currentUserId, setCurrentUserId] = useState<string | null>(null)
  const [currentUsername, setCurrentUsername] = useState<string>('')
  const [authDialogOpen, setAuthDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [coffeeType, setCoffeeType] = useState<CoffeeType>('espresso')
  const [sortBy, setSortBy] = useState<SortOption>('newest')
  const [newBeanDialogOpen, setNewBeanDialogOpen] = useState(false)
  const [extractionDialogOpen, setExtractionDialogOpen] = useState(false)
  const [tastingProfileDialogOpen, setTastingProfileDialogOpen] = useState(false)
  const [selectedBean, setSelectedBean] = useState<CoffeeBean | null>(null)
  const [editBeanDialogOpen, setEditBeanDialogOpen] = useState(false)
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [beanToDelete, setBeanToDelete] = useState<CoffeeBean | null>(null)

  useEffect(() => {
    const initAuth = async () => {
      try {
        const user = await spark.user()
        if (user && user.login) {
          setCurrentUserId(user.id)
          setCurrentUsername(user.login)
          setAuthDialogOpen(false)
        } else {
          const lastUserId = await spark.kv.get<string>('last-user-id')
          const lastUsername = await spark.kv.get<string>('last-username')
          
          if (lastUserId && lastUsername) {
            setCurrentUserId(lastUserId)
            setCurrentUsername(lastUsername)
            setAuthDialogOpen(false)
          } else {
            setAuthDialogOpen(true)
          }
        }
      } catch (error) {
        const lastUserId = await spark.kv.get<string>('last-user-id')
        const lastUsername = await spark.kv.get<string>('last-username')
        
        if (lastUserId && lastUsername) {
          setCurrentUserId(lastUserId)
          setCurrentUsername(lastUsername)
          setAuthDialogOpen(false)
        } else {
          setAuthDialogOpen(true)
        }
      } finally {
        setIsLoading(false)
      }
    }
    
    initAuth()
  }, [])

  const handleAuthenticated = async (userId: string, username: string) => {
    setCurrentUserId(userId)
    setCurrentUsername(username)
    setAuthDialogOpen(false)
    
    await spark.kv.set('last-user-id', userId)
    await spark.kv.set('last-username', username)
  }

  const handleSignOut = async () => {
    await spark.kv.delete('last-user-id')
    await spark.kv.delete('last-username')
    setCurrentUserId(null)
    setCurrentUsername('')
    setAuthDialogOpen(true)
    toast.success('Signed out successfully')
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Coffee size={48} weight="fill" className="mx-auto text-primary mb-4 animate-pulse" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  if (!currentUserId) {
    return (
      <>
        <AuthDialog open={authDialogOpen} onAuthenticated={handleAuthenticated} />
        <Toaster position="top-center" />
      </>
    )
  }

  return <AuthenticatedApp 
    currentUserId={currentUserId}
    currentUsername={currentUsername}
    onSignOut={handleSignOut}
    coffeeType={coffeeType}
    setCoffeeType={setCoffeeType}
    sortBy={sortBy}
    setSortBy={setSortBy}
    newBeanDialogOpen={newBeanDialogOpen}
    setNewBeanDialogOpen={setNewBeanDialogOpen}
    extractionDialogOpen={extractionDialogOpen}
    setExtractionDialogOpen={setExtractionDialogOpen}
    tastingProfileDialogOpen={tastingProfileDialogOpen}
    setTastingProfileDialogOpen={setTastingProfileDialogOpen}
    selectedBean={selectedBean}
    setSelectedBean={setSelectedBean}
  />
}

interface AuthenticatedAppProps {
  currentUserId: string
  currentUsername: string
  onSignOut: () => void
  coffeeType: CoffeeType
  setCoffeeType: (type: CoffeeType) => void
  sortBy: SortOption
  setSortBy: (sort: SortOption) => void
  newBeanDialogOpen: boolean
  setNewBeanDialogOpen: (open: boolean) => void
  extractionDialogOpen: boolean
  setExtractionDialogOpen: (open: boolean) => void
  tastingProfileDialogOpen: boolean
  setTastingProfileDialogOpen: (open: boolean) => void
  selectedBean: CoffeeBean | null
  setSelectedBean: (bean: CoffeeBean | null) => void
}

function AuthenticatedApp({
  currentUserId,
  currentUsername,
  onSignOut,
  coffeeType,
  setCoffeeType,
  sortBy,
  setSortBy,
  newBeanDialogOpen,
  setNewBeanDialogOpen,
  extractionDialogOpen,
  setExtractionDialogOpen,
  tastingProfileDialogOpen,
  setTastingProfileDialogOpen,
  selectedBean,
  setSelectedBean,
}: AuthenticatedAppProps) {
  const [beans, setBeans] = useKV<CoffeeBean[]>(
    `${currentUserId}:coffee-beans`,
    []
  )
  const [extractions, setExtractions] = useKV<Extraction[]>(
    `${currentUserId}:extractions`,
    []
  )
  const [tastingProfiles, setTastingProfiles] = useKV<TastingProfile[]>(
    `${currentUserId}:tasting-profiles`,
    []
  )

  const [filterOrigin, setFilterOrigin] = useState<string>('all')
  const [filterRoast, setFilterRoast] = useState<string>('all')
  const [isDataLoaded, setIsDataLoaded] = useState(false)
  const [editBeanDialogOpen, setEditBeanDialogOpen] = useState(false)
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [beanToDelete, setBeanToDelete] = useState<CoffeeBean | null>(null)

  useEffect(() => {
    const checkData = async () => {
      const keys = await spark.kv.keys()
      console.log('All KV keys:', keys)
      const beansData = await spark.kv.get(`${currentUserId}:coffee-beans`)
      console.log(`Beans data for ${currentUserId}:`, beansData)
      setIsDataLoaded(true)
    }
    checkData()
  }, [currentUserId])

  useEffect(() => {
    console.log('Beans state updated:', beans)
  }, [beans])

  const filteredBeans = useMemo(() => {
    let beansToFilter = (beans || []).filter((bean) => bean.type === coffeeType && !bean.archived)
    
    if (filterOrigin !== 'all') {
      beansToFilter = beansToFilter.filter((bean) => bean.origin === filterOrigin)
    }
    
    if (filterRoast !== 'all') {
      beansToFilter = beansToFilter.filter((bean) => bean.roastLevel === filterRoast)
    }
    
    switch (sortBy) {
      case 'oldest':
        return beansToFilter.sort((a, b) => a.createdAt - b.createdAt)
      case 'name-asc':
        return beansToFilter.sort((a, b) => a.name.localeCompare(b.name))
      case 'name-desc':
        return beansToFilter.sort((a, b) => b.name.localeCompare(a.name))
      case 'origin-asc':
        return beansToFilter.sort((a, b) => (a.origin || '').localeCompare(b.origin || ''))
      case 'origin-desc':
        return beansToFilter.sort((a, b) => (b.origin || '').localeCompare(a.origin || ''))
      case 'roast-asc':
        return beansToFilter.sort((a, b) => (a.roastLevel || '').localeCompare(b.roastLevel || ''))
      case 'roast-desc':
        return beansToFilter.sort((a, b) => (b.roastLevel || '').localeCompare(a.roastLevel || ''))
      case 'newest':
      default:
        return beansToFilter.sort((a, b) => b.createdAt - a.createdAt)
    }
  }, [beans, coffeeType, sortBy, filterOrigin, filterRoast])

  const handleSaveBean = async (beanData: Omit<CoffeeBean, 'id' | 'createdAt'>) => {
    const newBean: CoffeeBean = {
      ...beanData,
      id: ulid(),
      createdAt: Date.now(),
    }
    
    console.log('Saving new bean:', newBean)
    console.log('Current userId:', currentUserId)
    
    setBeans((currentBeans) => {
      const updated = [...(currentBeans || []), newBean]
      console.log('Updated beans array:', updated)
      return updated
    })
    
    setTimeout(async () => {
      const verifyBeans = await spark.kv.get(`${currentUserId}:coffee-beans`)
      console.log('Verified beans after save:', verifyBeans)
    }, 100)
    
    toast.success('Bean added successfully')
  }

  const handleAddExtraction = (bean: CoffeeBean) => {
    setSelectedBean(bean)
    setExtractionDialogOpen(true)
  }

  const handleSaveExtraction = (extractionData: Omit<Extraction, 'id' | 'timestamp'>) => {
    const newExtraction: Extraction = {
      ...extractionData,
      id: ulid(),
      timestamp: Date.now(),
    }
    setExtractions((current) => [...(current || []), newExtraction])
  }

  const handleCreateTastingProfile = (bean: CoffeeBean) => {
    setSelectedBean(bean)
    setTastingProfileDialogOpen(true)
  }

  const handleSaveTastingProfile = (profileData: Omit<TastingProfile, 'id' | 'timestamp'>) => {
    const newProfile: TastingProfile = {
      ...profileData,
      id: ulid(),
      timestamp: Date.now(),
    }
    setTastingProfiles((current) => [...(current || []), newProfile])
  }

  const getExtractionsForBean = (beanId: string) => {
    return (extractions || []).filter((e) => e.beanId === beanId)
  }

  const getTastingProfilesForBean = (beanId: string) => {
    return (tastingProfiles || []).filter((p) => p.beanId === beanId)
  }

  const handleEditBean = (bean: CoffeeBean) => {
    setSelectedBean(bean)
    setEditBeanDialogOpen(true)
  }

  const handleSaveBeanEdit = (beanId: string, updates: Partial<CoffeeBean>) => {
    setBeans((currentBeans) =>
      (currentBeans || []).map((bean) =>
        bean.id === beanId ? { ...bean, ...updates } : bean
      )
    )
    toast.success('Bean updated successfully')
  }

  const handleDeleteBean = (bean: CoffeeBean) => {
    setBeanToDelete(bean)
    setDeleteConfirmOpen(true)
  }

  const confirmDeleteBean = () => {
    if (!beanToDelete) return
    
    setBeans((currentBeans) =>
      (currentBeans || []).filter((bean) => bean.id !== beanToDelete.id)
    )
    
    setExtractions((currentExtractions) =>
      (currentExtractions || []).filter((extraction) => extraction.beanId !== beanToDelete.id)
    )
    
    setTastingProfiles((currentProfiles) =>
      (currentProfiles || []).filter((profile) => profile.beanId !== beanToDelete.id)
    )
    
    toast.success('Bean deleted successfully')
    setDeleteConfirmOpen(false)
    setBeanToDelete(null)
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-7xl mx-auto px-4 py-6 md:px-6 md:py-8">
        <header className="mb-8">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 tracking-tight">
                Coffee Dialer
              </h1>
              <p className="text-muted-foreground text-sm md:text-base">
                Perfect your espresso and filter coffee with intelligent extraction tracking
              </p>
            </div>
            <UserHeader username={currentUsername} onSignOut={onSignOut} />
          </div>
        </header>

        <Tabs value={coffeeType} onValueChange={(v) => setCoffeeType(v as CoffeeType)} className="space-y-6">
          <div className="flex flex-col gap-4">
            <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
              <TabsList className="grid w-full sm:w-auto grid-cols-2 h-11">
                <TabsTrigger value="espresso" className="gap-2 px-6">
                  <Coffee size={18} weight="fill" />
                  <span className="font-medium">Espresso</span>
                </TabsTrigger>
                <TabsTrigger value="filter" className="gap-2 px-6">
                  <Funnel size={18} weight="fill" />
                  <span className="font-medium">Filter</span>
                </TabsTrigger>
              </TabsList>

              <Button 
                onClick={() => setNewBeanDialogOpen(true)}
                className="gap-2 w-full sm:w-auto"
                size="default"
              >
                <Plus size={18} weight="bold" />
                Add Bean
              </Button>
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2">
                <SortAscending size={20} className="text-muted-foreground" />
                <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="name-asc">Name (A-Z)</SelectItem>
                    <SelectItem value="name-desc">Name (Z-A)</SelectItem>
                    <SelectItem value="origin-asc">Origin (A-Z)</SelectItem>
                    <SelectItem value="origin-desc">Origin (Z-A)</SelectItem>
                    <SelectItem value="roast-asc">Roast Level (A-Z)</SelectItem>
                    <SelectItem value="roast-desc">Roast Level (Z-A)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                <div className="flex items-center gap-2">
                  <Faders size={20} className="text-muted-foreground" />
                  <span className="text-sm font-medium text-muted-foreground">Filters:</span>
                </div>
                <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                  <Select value={filterOrigin} onValueChange={setFilterOrigin}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="All Origins" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Origins</SelectItem>
                      {COFFEE_ORIGINS.map((origin) => (
                        <SelectItem key={origin} value={origin}>
                          {origin}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={filterRoast} onValueChange={setFilterRoast}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="All Roast Levels" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roast Levels</SelectItem>
                      {ROAST_LEVELS.map((roast) => (
                        <SelectItem key={roast} value={roast}>
                          {roast}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {(filterOrigin !== 'all' || filterRoast !== 'all') && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => {
                        setFilterOrigin('all')
                        setFilterRoast('all')
                      }}
                      className="w-full sm:w-auto"
                    >
                      Clear Filters
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          <TabsContent value="espresso" className="mt-6">
            {filteredBeans.length === 0 ? (
              <div className="text-center py-16 px-4">
                <div className="max-w-md mx-auto space-y-4">
                  <Coffee size={64} weight="thin" className="mx-auto text-muted-foreground/50" />
                  <h3 className="text-xl font-semibold">No espresso beans yet</h3>
                  <p className="text-muted-foreground text-sm">
                    Start by adding your first espresso bean. Upload a photo of the package and we'll extract the details automatically.
                  </p>
                  <Button onClick={() => setNewBeanDialogOpen(true)} className="gap-2">
                    <Plus size={18} weight="bold" />
                    Add Your First Bean
                  </Button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredBeans.map((bean) => (
                  <BeanCard
                    key={bean.id}
                    bean={bean}
                    extractions={getExtractionsForBean(bean.id)}
                    tastingProfiles={getTastingProfilesForBean(bean.id)}
                    onAddExtraction={handleAddExtraction}
                    onCreateTastingProfile={handleCreateTastingProfile}
                    onEdit={handleEditBean}
                    onDelete={handleDeleteBean}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="filter" className="mt-6">
            {filteredBeans.length === 0 ? (
              <div className="text-center py-16 px-4">
                <div className="max-w-md mx-auto space-y-4">
                  <Funnel size={64} weight="thin" className="mx-auto text-muted-foreground/50" />
                  <h3 className="text-xl font-semibold">No filter coffee beans yet</h3>
                  <p className="text-muted-foreground text-sm">
                    Start by adding your first filter coffee bean. Upload a photo of the package and we'll extract the details automatically.
                  </p>
                  <Button onClick={() => setNewBeanDialogOpen(true)} className="gap-2">
                    <Plus size={18} weight="bold" />
                    Add Your First Bean
                  </Button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredBeans.map((bean) => (
                  <BeanCard
                    key={bean.id}
                    bean={bean}
                    extractions={getExtractionsForBean(bean.id)}
                    tastingProfiles={getTastingProfilesForBean(bean.id)}
                    onAddExtraction={handleAddExtraction}
                    onCreateTastingProfile={handleCreateTastingProfile}
                    onEdit={handleEditBean}
                    onDelete={handleDeleteBean}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <NewBeanDialog
        open={newBeanDialogOpen}
        onOpenChange={setNewBeanDialogOpen}
        coffeeType={coffeeType}
        onSave={handleSaveBean}
      />

      <ExtractionDialog
        open={extractionDialogOpen}
        onOpenChange={setExtractionDialogOpen}
        bean={selectedBean}
        onSave={handleSaveExtraction}
      />

      <TastingProfileDialog
        open={tastingProfileDialogOpen}
        onOpenChange={setTastingProfileDialogOpen}
        bean={selectedBean}
        onSave={handleSaveTastingProfile}
      />

      <EditBeanDialog
        open={editBeanDialogOpen}
        onOpenChange={setEditBeanDialogOpen}
        bean={selectedBean}
        onSave={handleSaveBeanEdit}
      />

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Bean</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{beanToDelete?.name}"? This will also delete all associated extractions and tasting profiles. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteBean} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Toaster position="top-center" />
    </div>
  )
}

export default App