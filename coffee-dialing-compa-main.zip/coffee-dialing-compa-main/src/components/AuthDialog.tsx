import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { User, Envelope, GithubLogo } from '@phosphor-icons/react'
import { toast } from 'sonner'

interface AuthDialogProps {
  open: boolean
  onAuthenticated: (userId: string, username: string) => void
}

interface UserCredentials {
  username: string
  email: string
  password: string
}

export function AuthDialog({ open, onAuthenticated }: AuthDialogProps) {
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [isSignIn, setIsSignIn] = useState(true)
  const [authMethod, setAuthMethod] = useState<'username' | 'email'>('username')

  const handleUsernameSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!username.trim()) {
      toast.error('Please enter a username')
      return
    }

    setLoading(true)

    try {
      const userId = username.toLowerCase().replace(/\s+/g, '-')
      const existingUser = await spark.kv.get<{ username: string }>(`user:${userId}`)

      if (isSignIn && !existingUser) {
        toast.error('User not found. Please create an account.')
        setLoading(false)
        return
      }

      if (!isSignIn && existingUser) {
        toast.error('Username already exists. Please sign in.')
        setLoading(false)
        return
      }

      if (!existingUser) {
        await spark.kv.set(`user:${userId}`, { username: username.trim() })
        toast.success('Account created successfully!')
      } else {
        toast.success('Signed in successfully!')
      }

      onAuthenticated(userId, username.trim())
    } catch (error) {
      console.error('Auth error:', error)
      toast.error('Authentication failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email.trim() || !password.trim()) {
      toast.error('Please enter both email and password')
      return
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      toast.error('Please enter a valid email address')
      return
    }

    if (!isSignIn && password !== confirmPassword) {
      toast.error('Passwords do not match')
      return
    }

    if (!isSignIn && password.length < 6) {
      toast.error('Password must be at least 6 characters')
      return
    }

    setLoading(true)

    try {
      const emailKey = `email:${email.toLowerCase()}`
      const existingUser = await spark.kv.get<UserCredentials>(emailKey)

      if (isSignIn) {
        if (!existingUser) {
          toast.error('No account found with this email. Please create an account.')
          setLoading(false)
          return
        }

        if (existingUser.password !== password) {
          toast.error('Incorrect password')
          setLoading(false)
          return
        }

        toast.success('Signed in successfully!')
        const userId = email.toLowerCase().replace(/[@.]/g, '-')
        onAuthenticated(userId, existingUser.username)
      } else {
        if (existingUser) {
          toast.error('An account with this email already exists. Please sign in.')
          setLoading(false)
          return
        }

        if (!username.trim()) {
          toast.error('Please enter a username')
          setLoading(false)
          return
        }

        const userId = email.toLowerCase().replace(/[@.]/g, '-')
        const credentials: UserCredentials = {
          username: username.trim(),
          email: email.toLowerCase(),
          password: password,
        }

        await spark.kv.set(emailKey, credentials)
        await spark.kv.set(`user:${userId}`, { username: username.trim(), email: email.toLowerCase() })
        
        toast.success('Account created successfully!')
        onAuthenticated(userId, username.trim())
      }
    } catch (error) {
      console.error('Auth error:', error)
      toast.error('Authentication failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleGitHubAuth = async () => {
    setLoading(true)
    try {
      const user = await spark.user()
      if (user && user.login) {
        toast.success('Signed in with GitHub!')
        onAuthenticated(user.id, user.login)
      } else {
        toast.error('GitHub authentication failed. Please try another method.')
      }
    } catch (error) {
      console.error('GitHub auth error:', error)
      toast.error('GitHub authentication failed. Please try another method.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-[450px]">
        <DialogHeader>
          <DialogTitle>{isSignIn ? 'Sign In' : 'Create Account'}</DialogTitle>
          <DialogDescription>
            Choose your preferred authentication method
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <Tabs value={authMethod} onValueChange={(v) => setAuthMethod(v as 'username' | 'email')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="username" className="gap-2">
                <User size={16} weight="fill" />
                Username
              </TabsTrigger>
              <TabsTrigger value="email" className="gap-2">
                <Envelope size={16} weight="fill" />
                Email
              </TabsTrigger>
            </TabsList>

            <TabsContent value="username" className="space-y-4 mt-4">
              <form onSubmit={handleUsernameSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter your username"
                    autoFocus
                    disabled={loading}
                  />
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full gap-2"
                >
                  <User size={18} weight="fill" />
                  {loading ? 'Please wait...' : isSignIn ? 'Sign In' : 'Create Account'}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="email" className="space-y-4 mt-4">
              <form onSubmit={handleEmailSubmit} className="space-y-4">
                {!isSignIn && (
                  <div className="space-y-2">
                    <Label htmlFor="email-username">Username</Label>
                    <Input
                      id="email-username"
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="Choose a username"
                      disabled={loading}
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    disabled={loading}
                    autoComplete="email"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    disabled={loading}
                    autoComplete={isSignIn ? 'current-password' : 'new-password'}
                  />
                </div>

                {!isSignIn && (
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm Password</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Confirm your password"
                      disabled={loading}
                      autoComplete="new-password"
                    />
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full gap-2"
                >
                  <Envelope size={18} weight="fill" />
                  {loading ? 'Please wait...' : isSignIn ? 'Sign In' : 'Create Account'}
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">Or</span>
            </div>
          </div>

          <Button
            type="button"
            variant="outline"
            className="w-full gap-2"
            onClick={handleGitHubAuth}
          >
            <GithubLogo size={18} weight="fill" />
            Continue with GitHub
          </Button>

          <div className="text-center text-sm">
            {isSignIn ? (
              <p className="text-muted-foreground">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => setIsSignIn(false)}
                  disabled={loading}
                  className="text-primary hover:underline font-medium"
                >
                  Create one
                </button>
              </p>
            ) : (
              <p className="text-muted-foreground">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => setIsSignIn(true)}
                  disabled={loading}
                  className="text-primary hover:underline font-medium"
                >
                  Sign in
                </button>
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
